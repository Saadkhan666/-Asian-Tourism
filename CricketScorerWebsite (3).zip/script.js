
document.addEventListener("DOMContentLoaded", () => {
    console.log("Cricket Scorer app loaded.");
});
